## Instructions for the SWEEP files
The sweep files are put in a seperate folder but are to be called/ run when having the source.py file in the same directory. This is been put under seperate folder 
for the interpretability of the source.py and train.py files. These files in the SWEEP folder was used for the report writing in WandB.
